select 'alter system kill session '||''''|| b.sid||','||b.SERIAL#||''''|| ' ;  ' ||b.inst_id
from gv$locked_object a ,gv$session b,dba_objects c where b.Sid = a.Session_Id
and a.Object_Id = c.Object_Id and b.status='ACTIVE' AND 
C.OBJECT_NAME='DOCUMENT_NUMBER_CONTROL'
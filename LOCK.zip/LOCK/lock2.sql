col owner format a10
col sid format 99999
col serial# format 99999
col inst_id format 99
col MACHINE format a12
col Object_Type format a8
col Osuser format a5
select b.INST_ID,b.Sid,b.Serial#,c.Object_Name, to_char(logon_time,'dd-mm-yy hh:mi:ss AM')"Time", b.Status,b.Osuser
from gv$locked_object a ,gv$session b,dba_objects c where b.Sid = a.Session_Id
and a.Object_Id = c.Object_Id and b.status='ACTIVE'
order by 2,3,5
/
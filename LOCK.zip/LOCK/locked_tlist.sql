select b.username,c.Owner,c.Object_Name,c.Object_Type,b.Sid,b.Serial#,b.Status,b.INST_ID
from gv$locked_object a ,gv$session b,dba_objects c where b.Sid = a.Session_Id
and a.Object_Id = c.Object_Id and b.status='ACTIVE' and c.object_name='DOCUMENT_NUMBER_CONTROL'
/

col username format a8
col owner format a10
col sid format 99999
col serial# format 9999999
col inst_id format 999
col object_name format a30
col object_type format a12
col status format a8
select b.username,c.Owner,c.Object_Name,c.Object_Type,b.Sid,b.Serial#,b.Status,b.INST_ID
from gv$locked_object a ,gv$session b,dba_objects c where b.Sid = a.Session_Id
and a.Object_Id = c.Object_Id and b.status='ACTIVE'
/
